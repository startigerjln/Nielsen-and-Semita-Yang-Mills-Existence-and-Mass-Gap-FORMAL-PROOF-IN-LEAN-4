import Lake
open Lake DSL

package YangMillsMassGap where
  leanOptions := #[
    ⟨`autoImplicit, false⟩
  ]

@[default_target]
lean_lib YangMillsMassGap where
  srcDir := "YangMillsMassGap"

require mathlib from git
  "https://github.com/leanprover-community/mathlib4" @ "v4.14.0"
