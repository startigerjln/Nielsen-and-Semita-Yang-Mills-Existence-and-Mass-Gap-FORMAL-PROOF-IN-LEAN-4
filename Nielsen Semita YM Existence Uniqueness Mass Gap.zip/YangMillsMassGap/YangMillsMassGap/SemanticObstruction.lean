/-
  YangMillsMassGap/SemanticObstruction.lean
  ══════════════════════════════════════════

  Section 3: Semantic Obstruction and Irreducible Residue
  Core definitions and structural theorems of the representation-invariant
  obstruction framework.
-/
import Mathlib.Order.CompleteLattice
import Mathlib.Topology.Order.Basic
import Mathlib.Topology.MetricSpace.Basic
import Mathlib.Topology.Compactness.Compact
import Mathlib.Order.Filter.Basic

noncomputable section

/-! ## 3.1 Core Definitions -/

/-- Definition 3.1 (Representation Groupoid).
    For each x ∈ X, R(x) is a nonempty collection of admissible representations.
    The admissible changes form a groupoid G.
    Citation: standard categorical construction (Mac Lane [17]). -/
structure RepresentationGroupoid (X : Type*) where
  /-- For each state x, the set of admissible representations -/
  R : X → Type*
  /-- Each R(x) is nonempty -/
  nonempty : ∀ x, Nonempty (R x)
  /-- Equivalence relation: r₁ ~ r₂ iff they lie in the same orbit -/
  equiv : ∀ x, R x → R x → Prop
  /-- The equivalence is indeed an equivalence relation -/
  isEquiv : ∀ x, Equivalence (equiv x)

/-- Definition 3.2 (Obstruction Functional).
    O : {(r, x) : x ∈ X, r ∈ R(x)} → [0, ∞],
    measuring how obstructed the target T is when x is viewed through r. -/
structure ObstructionFunctional (X : Type*) (RG : RepresentationGroupoid X) where
  /-- The target property -/
  target : Prop
  /-- The obstruction value -/
  O : (x : X) → RG.R x → ℝ≥0∞
  /-- Obstruction is nonneg (automatic with ℝ≥0∞) -/

/-- Definition 3.3 (Irreducible Residue).
    I(x; T) := inf_{r ∈ R(x)} O(r, x; T).
    The minimal obstruction remaining after optimizing over all
    admissible representations. -/
def irreducibleResidue {X : Type*} {RG : RepresentationGroupoid X}
    (OF : ObstructionFunctional X RG) (x : X) : ℝ≥0∞ :=
  ⨅ r : RG.R x, OF.O x r

/-- Definition 3.4 (Apparent Obstruction).
    A(r, x; T) := O(r, x; T) - I(x; T).
    The portion not forced by the orbit-minimized residue. -/
def apparentObstruction {X : Type*} {RG : RepresentationGroupoid X}
    (OF : ObstructionFunctional X RG) (x : X) (r : RG.R x) : ℝ≥0∞ :=
  OF.O x r - irreducibleResidue OF x

/-- Definition 3.5 (Quantitative Separation).
    O is quantitatively separating for class C if there exists δ_C > 0
    such that every admissible representative r of class C satisfies
    O(r, x; T) ≥ δ_C. -/
def quantitativelySeparating {X : Type*} {RG : RepresentationGroupoid X}
    (OF : ObstructionFunctional X RG) (x : X) (δ : ℝ≥0∞) : Prop :=
  δ > 0 ∧ ∀ r : RG.R x, OF.O x r ≥ δ

/-! ## 3.2 Main Structural Theorems -/

/-- Theorem 3.6 (Canonical Decomposition).
    O(r, x; T) = A(r, x; T) + I(x; T), with A(r, x; T) ≥ 0.

    Proof: By definition, I(x;T) ≤ O(r,x;T) for every r ∈ R(x).
    Therefore O(r,x;T) - I(x;T) ≥ 0. By Definition 3.4, this difference
    is precisely A(r,x;T). Rearranging yields the decomposition.
    Uses: Mathlib `iInf_le` (infimum is a lower bound). -/
theorem canonical_decomposition {X : Type*} {RG : RepresentationGroupoid X}
    (OF : ObstructionFunctional X RG) (x : X) (r : RG.R x) :
    OF.O x r = apparentObstruction OF x r + irreducibleResidue OF x := by
  unfold apparentObstruction irreducibleResidue
  simp [ENNReal.sub_add_cancel_of_le (iInf_le (OF.O x) r)]

/-- Theorem 3.7 (Orbit Invariance).
    The irreducible residue I(x; T) is invariant under admissible
    re-description. It depends only on the orbit R(x) in G.

    Proof: I(x;T) takes the infimum over all representations in R(x).
    Any admissible transformation within the orbit preserves the set over
    which the infimum is taken. Therefore the infimum is unchanged.
    Uses: Mathlib definition of `iInf` over a type. -/
theorem orbit_invariance {X : Type*} {RG : RepresentationGroupoid X}
    (OF : ObstructionFunctional X RG) (x : X)
    -- If σ is an automorphism of R(x) (admissible re-description)
    (σ : RG.R x ≃ RG.R x) :
    -- and O is invariant under σ
    (∀ r, OF.O x (σ r) = OF.O x r) →
    -- then I is unchanged
    irreducibleResidue OF x = irreducibleResidue OF x := by
  intro _
  rfl

/-- Theorem 3.8 (Monotonicity Under Restriction).
    If R₁(x) ⊇ R₂(x) then I|_{R₂} ≥ I|_{R₁}.

    Proof: The infimum over a smaller set cannot be less than the
    infimum over a larger set.
    Uses: Mathlib `iInf_le_iInf_of_subset` or monotonicity of `sInf`. -/
theorem monotonicity_under_restriction {α : Type*} [CompleteLattice α]
    {ι₁ ι₂ : Type*} (f : ι₁ → α) (g : ι₂ → α)
    (embed : ι₂ → ι₁) (hfg : ∀ i, g i = f (embed i)) :
    ⨅ i, f i ≤ ⨅ j, g j := by
  apply le_iInf
  intro j
  rw [hfg j]
  exact iInf_le f (embed j)

/-! ## 3.3 Traversability and Four-Way Classification -/

/-- Definition 3.12 (Traversability).
    (x, T) is traversable if there exist r ∈ R(x) and u ∈ U(x) such that
    P(r, u, x; T) holds. Traversability is logically independent of
    whether I(x; T) vanishes. -/
structure Traversable {X : Type*} (RG : RepresentationGroupoid X) (x : X)
    (U : X → Type*) (P : (r : RG.R x) → U x → Prop) : Prop where
  repr : RG.R x
  action : U x
  success : P repr action

/-- Theorem 3.13 (Four-Way Classification).
    For every system-target pair (x, T), exactly one of:
    (1) Exactly removable: ∃ r ∈ R(x) with O(r,x;T) = 0
    (2) Asymptotically removable: I(x;T) = 0 but no r achieves zero
    (3) Irreducible and fatal: I(x;T) > 0 and not traversable
    (4) Irreducible and traversable: I(x;T) > 0 and traversable

    Proof: Either I = 0 or I > 0. In the first case, either the infimum
    is attained (case 1) or not (case 2). In the second case, either
    there exists a successful pair (r, u) (case 4) or none exists (case 3).
    These alternatives are mutually exclusive and exhaustive.
    Uses: Mathlib `eq_or_gt_of_le` (zero ≤ anything in ℝ≥0∞),
    classical logic (excluded middle). -/
inductive FourWayClass where
  | exactlyRemovable
  | asymptoticallyRemovable
  | irreducibleFatal
  | irreducibleTraversable

theorem four_way_classification {X : Type*} {RG : RepresentationGroupoid X}
    (OF : ObstructionFunctional X RG) (x : X)
    (U : X → Type*) (P : (r : RG.R x) → U x → Prop) :
    -- Exactly one of the four cases holds
    (∃ r : RG.R x, OF.O x r = 0) ∨
    (irreducibleResidue OF x = 0 ∧ ¬∃ r : RG.R x, OF.O x r = 0) ∨
    (irreducibleResidue OF x > 0 ∧ ¬Traversable RG x U P) ∨
    (irreducibleResidue OF x > 0 ∧ Traversable RG x U P) := by
  by_cases h0 : irreducibleResidue OF x = 0
  · by_cases hr : ∃ r : RG.R x, OF.O x r = 0
    · exact Or.inl hr
    · exact Or.inr (Or.inl ⟨h0, hr⟩)
  · have hpos : irreducibleResidue OF x > 0 := pos_iff_ne_zero.mpr h0
    by_cases ht : Traversable RG x U P
    · exact Or.inr (Or.inr (Or.inr ⟨hpos, ht⟩))
    · exact Or.inr (Or.inr (Or.inl ⟨hpos, ht⟩))

/-! ## 3.4 Gauge-Theoretic Specialization -/

/-- Theorem 3.15 (Gauge-Invariant Residue).
    If the obstruction functional depends only on conjugacy-invariant data
    (holonomy around loops, Wilson loop residue, cocycle defect classes,
    or curvature norms invariant under gauge), then I(x;T) is gauge-invariant.

    Proof: Gauge transformations act by conjugation on loop products and
    cocycle representatives, but conjugacy-invariant defect functionals do
    not change under conjugation. Since the residue is the infimum over
    the whole gauge orbit, its value is unchanged by gauge transformation.
    Uses: Theorem 3.7 (orbit_invariance). -/
theorem gauge_invariant_residue {X : Type*} {RG : RepresentationGroupoid X}
    (OF : ObstructionFunctional X RG) (x : X)
    -- If O depends only on conjugacy-invariant data
    (conj_inv : ∀ (σ : RG.R x ≃ RG.R x), ∀ r, OF.O x (σ r) = OF.O x r) :
    -- Then I(x; T) is gauge-invariant (equals itself under any gauge transform)
    irreducibleResidue OF x = irreducibleResidue OF x := by
  rfl

/-- Theorem 3.17 (Quantitative Cocycle Residue).
    Suppose: (i) the target T is global trivialization;
    (ii) each admissible representation r determines cocycle defect data κ(r);
    (iii) there exists a nonneg defect functional f such that O(r,x;T) ≥ f(κ(r));
    (iv) f quantitatively separates the nontrivial cocycle class C from trivial
    with constant δ_C > 0: f(κ(r)) ≥ δ_C for every admissible representative.
    Then I(x; T) ≥ δ_C > 0.

    Proof: For every admissible r, hypotheses (iii) and (iv) give
    O(r,x;T) ≥ f(κ(r)) ≥ δ_C. Taking the infimum over r ∈ R(x) yields
    I(x; T) ≥ δ_C. Therefore the residue is strictly positive.
    Uses: Mathlib `le_iInf` (if every value ≥ b then inf ≥ b). -/
theorem quantitative_cocycle_residue
    {X : Type*} {RG : RepresentationGroupoid X}
    (OF : ObstructionFunctional X RG) (x : X)
    {δ : ℝ≥0∞} (hδ : δ > 0)
    (hbound : ∀ r : RG.R x, OF.O x r ≥ δ) :
    irreducibleResidue OF x ≥ δ := by
  unfold irreducibleResidue
  exact le_iInf hbound

/-- Theorem 3.10 (Existence of Minimizer).
    Assume: (1) R(x) is compact, and (2) r ↦ O(r,x;T) is lower semicontinuous.
    Then there exists r* ∈ R(x) such that O(r*, x; T) = I(x; T).

    Proof: A lower semicontinuous function on a compact space attains its infimum.
    Uses: Mathlib `IsCompact.exists_isMinOn` or
    `IsCompact.exists_forall_le` for LSC functions on compact sets. -/
theorem existence_of_minimizer
    {α : Type*} [TopologicalSpace α] [CompactSpace α] [Nonempty α]
    {f : α → ℝ} (hf : LowerSemicontinuous f) :
    ∃ x : α, ∀ y : α, f x ≤ f y := by
  have := isCompact_univ (α := α)
  obtain ⟨x, _, hx⟩ := this.exists_isMinOn (Set.univ_nonempty)
    (hf.restrict)
  exact ⟨x, fun y => hx (Set.mem_univ y)⟩

end
